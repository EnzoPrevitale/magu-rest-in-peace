# Database
DATABASE_HOST="localhost"
DATABASE_USER="magu"
DATABASE_PASSWORD="magu"
DATABASE_PORT=3306
DATABASE_NAME="magu"

# Server
SERVER_HOST="localhost"
SERVER_PORT=8000
SERVER_ADDRESS = f"http://{SERVER_HOST}:{SERVER_PORT}"

# Authentication
SECRET_KEY="secret_key_123"
